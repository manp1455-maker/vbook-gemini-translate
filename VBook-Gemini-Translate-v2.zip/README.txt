# Gemini Translate cho VBook

Extension dạng `translate` cho VBook, dùng Google Gemini API.

Cấu trúc:
- plugin.json
- src/language.js
- src/translate.js

Model mặc định: gemini-3.1-pro-preview.
Có thể đổi model và prompt trong phần cấu hình extension.
