function execute(text, from, to, source) {
    text = text || "";
    from = from || "zh-CN";
    to = to || "vi";

    if (!text) return Response.success("");
    if (!GEMINI_API_KEY) return Response.error("Chưa nhập Gemini API Key.");

    var prompt = CUSTOM_PROMPT || "Dịch văn bản sang tiếng Việt tự nhiên.";
    var model = GEMINI_MODEL || "gemini-3.1-pro-preview";
    var temperature = parseFloat(TEMPERATURE || "0.2");
    var maxTokens = parseInt(MAX_OUTPUT_TOKENS || "12000");

    var instruction =
        prompt +
        "\n\nNgôn ngữ nguồn: " + from +
        "\nNgôn ngữ đích: " + to +
        "\n\nVăn bản cần dịch:\n" + text;

    var url = "https://generativelanguage.googleapis.com/v1beta/models/" +
        model + ":generateContent?key=" + GEMINI_API_KEY;

    var response = fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            contents: [
                {
                    role: "user",
                    parts: [
                        { text: instruction }
                    ]
                }
            ],
            generationConfig: {
                temperature: temperature,
                maxOutputTokens: maxTokens
            }
        }),
        timeout: 120000
    });

    if (!response.ok) {
        return Response.error(
            "Gemini API lỗi HTTP " + response.status + ": " + response.text()
        );
    }

    var data = response.json();

    try {
        var result = data.candidates[0].content.parts
            .map(function(part) { return part.text || ""; })
            .join("");
        if (!result) return Response.error("Gemini không trả về nội dung.");
        return Response.success(result);
    } catch (e) {
        return Response.error("Không đọc được phản hồi Gemini: " + response.text());
    }
}