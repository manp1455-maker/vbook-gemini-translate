function execute() {
    return Response.success([
        { name: "Tiếng Trung", code: "zh-CN" },
        { name: "Tiếng Việt", code: "vi" }
    ]);
}