function execute(text, from, to) {
    if (!text || !text.trim()) return Response.success("");

    var keys = api_key;
    if (typeof keys === "string") keys = [keys];
    if (!keys || keys.length === 0 || !keys[0]) return Response.error("Chưa nhập Gemini API Key.");

    var key = keys[0];
    var selectedModel = model || "gemini-3.1-pro-preview";
    var temp = parseFloat(temperature || "0.3");
    var maxTokens = parseInt(max_output_tokens || "12000", 10);
    var instruction = prompt || "Dịch tiếng Trung sang tiếng Việt tự nhiên như tiểu thuyết.";
    var url = "https://generativelanguage.googleapis.com/v1beta/models/" +
        selectedModel + ":generateContent?key=" + encodeURIComponent(key);

    var response = fetch(url, {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({
            contents: [{role: "user", parts: [{text: instruction + "\n\n" + text}]}],
            generationConfig: {temperature: temp, maxOutputTokens: maxTokens}
        })
    });

    if (!response.ok) return Response.error("Gemini HTTP " + response.status + ": " + response.text());

    var data = response.json();
    if (!data.candidates || !data.candidates.length || !data.candidates[0].content) {
        return Response.error("Gemini không trả về bản dịch: " + JSON.stringify(data));
    }

    var parts = data.candidates[0].content.parts || [];
    var result = "";
    for (var i = 0; i < parts.length; i++) if (parts[i].text) result += parts[i].text;

    if (!result.trim()) return Response.error("Gemini trả về bản dịch rỗng.");
    return Response.success(result.trim());
}
