GEMINI TRANSLATE - VBOOK

Extension type=translate của VBook.
Có API Key, chọn model, Temperature, Max Output Tokens và Prompt tùy chỉnh.

Cài xong:
1. Nhập Gemini API Key.
2. Chọn gemini-3.1-pro-preview.
3. Temperature 0.3.
4. Max output tokens 12000.
5. Prompt đã có sẵn và có thể sửa.
