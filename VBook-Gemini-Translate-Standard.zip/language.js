function execute() {
    return Response.success([
        { code: "zh", name: "中文" },
        { code: "vi", name: "Tiếng Việt" }
    ]);
}
